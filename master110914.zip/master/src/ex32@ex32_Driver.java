import com.ltree.crs516.controller.TehiGame;
import com.ltree.crs516.view.MainFrame;

public class Driver {
	public static void main(String[] args) {
		new MainFrame(new TehiGame());
	}
}
