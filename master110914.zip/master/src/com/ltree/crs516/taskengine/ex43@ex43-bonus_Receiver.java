package com.ltree.crs516.taskengine;

public interface Receiver {
	//Just a marker interface: no methods.
}
