package com.ltree.crs516.client;

import com.ltree.crs516.domain.IStation;

public interface Displayer {
	String createDisplayString(IStation station);
}
