import com.ltree.crs516.MainFrame;

public class Driver {
	public static void main(String[] args) {
		new MainFrame();
	}
}
