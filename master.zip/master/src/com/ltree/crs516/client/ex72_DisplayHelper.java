package com.ltree.crs516.client;

@import com.ltree.crs516.domain.IStation;
$import com.ltree.crs516.domain.Station;

public interface DisplayHelper {
@	String mineStation(IStation station);
$	String mineStation(Station station);		
}
