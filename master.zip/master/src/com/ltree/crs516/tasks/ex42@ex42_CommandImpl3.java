package com.ltree.crs516.tasks;

import com.ltree.crs516.taskengine.Command;

 @SuppressWarnings("serial")
public class CommandImpl3 implements Command {

	@Override
	public void run() {
		System.out.println("Running command 3");	
	}

}
