/*
 * Placeholder -- Not yet developed
 */
package com.ltree.crs516.domain;

/**
 * This class represents a WOD09 station. A station is data from one 
 * or more casts at one geographic location.
 * 
 * @author crs516 development team
 * 
 */
public class Station {
//TODO 1: Note: At this point you only need a fake object with the correct 
//fully qualified name to test the controller as it is just a pass through object.
	
//Currently empty.
	
}
