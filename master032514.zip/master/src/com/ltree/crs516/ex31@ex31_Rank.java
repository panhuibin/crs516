package com.ltree.crs516;

import java.util.Random;

enum Rank {
	ACE("A", 1), TWO("2", 2), THREE("3", 3), FOUR("4", 4), FIVE("5", 5), SIX(
			"6", 6), SEVEN("7", 7), EIGHT("8", 8), NINE("9", 9), TEN("10", 10), JACK(
			"J", 11), QUEEN("Q", 12), KING("K", 13);

	public String getName() {
		return name;
	}

	public int getRankNumber() {
		return rankNumber;
	}

	private String name;
	private int rankNumber;

	private Rank(String name, int rankNumber) {
		this.name = name;
		this.rankNumber = rankNumber;
	}

	/**
	 * Converts an int to a Rank.
	 * 
	 * @param rankInt
	 * @return The corresponding Rank object.
	 */
	public static Rank convertIntToRank(int rankInt) {
		for (Rank rank : Rank.values()) {
			if (rank.rankNumber == rankInt) {
				return rank;
			}
		}
		return null;
	}

	/**
	 * Selects a rank at random.
	 * 
	 * @return a randomly selected rank.
	 */
	static Rank chooseRank() {
		Random random = new Random();
		int rankNumber = random.nextInt(13) + 1;
		switch (rankNumber) {
		case 11:
			return Rank.JACK;
		case 12:
			return Rank.QUEEN;
		case 13:
			return Rank.KING;
		default:
			Rank rank = Rank.convertIntToRank(rankNumber);
			System.out.println("rank is " + rank);
			return rank;
		}
	}

	public String toString() {
		return name;
	}
}