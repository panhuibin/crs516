package com.ltree.crs516;

import java.util.Random;

enum Suite {
	SPADE("spade"), CLUB("club"), DIAMOND("diamond"), HEART("heart");
	
	private String name;
	
	private Suite(String name){
		this.name = name;
	}
	
	public String toString(){
		return name;
	}
	
	/**
	 * Randomly selects a suite.
	 * @return
	 */
	public static Suite chooseSuite() {
		Random random = new Random();
		int suitNumber = random.nextInt(4)+1;
		switch(suitNumber){
		case 1:
			return Suite.SPADE;
		case 2:
			return Suite.CLUB;
		case 3:
			return Suite.DIAMOND;
		case 4:
			return Suite.HEART;
		}
		return null;
	}

}
