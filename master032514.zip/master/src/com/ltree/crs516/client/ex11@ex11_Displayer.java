package com.ltree.crs516.client;

import com.ltree.crs516.domain.Station;

public interface Displayer {
	String createDisplayString(Station station);
}
