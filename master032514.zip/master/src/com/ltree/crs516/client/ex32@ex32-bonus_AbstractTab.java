package com.ltree.crs516.client;

import java.util.Observable;

import javax.swing.JEditorPane;
import javax.swing.JPanel;

import com.ltree.crs516.domain.Station;

 @SuppressWarnings("serial")
public abstract class AbstractTab extends JPanel {

	/**
	 * To display the data.
	 */
	protected JEditorPane textArea = new JEditorPane("text/html", "");

	public AbstractTab() {
		super();
	}

	
	protected abstract String createDisplayString(Station station);

	public void update(Observable controller, Object theStation) {
		display((Station)theStation);
	}

	/**
	 * Displays the data that goes with a station.
	 * @param theStation
	 *            The Station whose data is to be displayed.
	 *            
	 * @param  controller.           
	 */
	public void display(Station station) {
			textArea.setText("");
			
	//TODO 1 : Extract the material between //{{Marker 1 and  //}}Marker 1
	//into a method called createDisplayString.
			
	String theDisplayString = createDisplayString(station);
	
			textArea.setText(theDisplayString);
		}

	public void setTextArea(JEditorPane textArea) {
		this.textArea = textArea;
	}

}