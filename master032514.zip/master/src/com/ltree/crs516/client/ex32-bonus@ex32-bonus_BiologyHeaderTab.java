
package com.ltree.crs516.client;

import java.awt.BorderLayout;
import java.util.Observer;

import javax.swing.JScrollPane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.domain.Station;


/**
 * A tab to hold information from the biological header section. It contains
 * information on the sampling methods used for collecting taxonomic and biomass
 * measurements. "Biological" data are arbitrarily defined as plankton biomass
 * (weights or volumes) and taxa-specific observations. It does not include
 * chlorophyll data.
 * 
 * @author crs516 development team
 * 
 */
 @SuppressWarnings("serial")
public final class BiologyHeaderTab extends AbstractTab implements Observer{

	private Logger logger = LoggerFactory.getLogger(getClass());
	private DisplayHelper helper;

	public void setHelper(DisplayHelper helper) {
		this.helper = helper;
	}

	public BiologyHeaderTab() {
		logger.debug("Initializing {}",getClass().getName());
		setLayout(new BorderLayout());
		this.add(new JScrollPane(textArea), BorderLayout.CENTER);
	}
	
	@Override
	protected String createDisplayString(Station station) {
		String theDisplayString = helper.mineStation(station);
		return theDisplayString;
	}
}
