
package com.ltree.crs516.client;

import java.awt.BorderLayout;
import java.util.Observer;

import javax.swing.JScrollPane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.domain.Station;


/**
 * A tab to hold information from the character data and principal investigator
 * information. The character data is used to report the originator's cruise 
 * identification and the originator's station identification. The Principal 
 * Investigator is the person responsible for collecting the data and is 
 * included whenever available.
 * 
 * @author crs516 development team
 * 
 */
 @SuppressWarnings("serial")
public final class CharacterDataTab extends AbstractTab implements Observer{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	private DisplayHelper helper;

	public void setHelper(DisplayHelper helper) {
		this.helper = helper;
	}	

	public CharacterDataTab(){
		logger.debug("Initializing {}",getClass().getName());
		setLayout(new BorderLayout());
		this.add(new JScrollPane(textArea), BorderLayout.CENTER);
	}
	
	@Override
	protected String createDisplayString(Station station) {
		String theDisplayString = helper.mineStation(station);
		return theDisplayString;
	}
}
