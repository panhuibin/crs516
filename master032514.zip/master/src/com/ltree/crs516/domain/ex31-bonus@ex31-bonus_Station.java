/*
 * Placeholder -- Not yet developed
 */
package com.ltree.crs516.domain;

/**
 * This class represents a WOD09 station. A station is data from one 
 * or more casts at one geographic location. The WOC09 documentation
 * is at http://www.nodc.noaa.gov/OC5/WOD09/pr_wod09.html
 * A station's data will include primary header, 
 * secondary header, variable-specific second header, 
 * character data, biological header, 
 * taxa-specific and biomass data, and measured variables.
 * 
 * @author crs516 development team
 * 
 */
public class Station {
//TODO 1: Note: We only need a dummy object with the correct fully qualified
//name to test the controller as it is just a pass through object.
	
//Currently empty.
	
}
