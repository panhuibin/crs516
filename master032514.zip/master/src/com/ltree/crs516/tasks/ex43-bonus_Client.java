package com.ltree.crs516.tasks;

import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.taskengine.Command;
import com.ltree.crs516.taskengine.Receiver;
import com.ltree.crs516.taskengine.TaskEngine;
import com.ltree.crs516.tasks.NamingPatternCommandImpl;
import com.ltree.crs516.tasks.NamingPatternReceiverImpl;

/**
 * Creates and submits CommandImpl to the task engine.
 * 
 * @author crs516 development team
 * 
 */
public final class Client {

	private final Logger logger = LoggerFactory.getLogger(Client.class);

	/**
	 * Looks up task engine, instantiates CommandImpl and submits it to task
	 * engine.
	 */
	public void prepareAndSubmitCommand() {

//TODO 1: Comment out the code between the markers //{{marker 1 and // end marker 1 }}
		
//{{marker 1		
		
$			Command annotationCommandImpl = new AnnotationCommandImpl();
$			Receiver annotationReceiverImpl = new AnnotationReceiverImpl();
$			annotationCommandImpl.setReceiver(annotationReceiverImpl);
$			logger.info("Annotation based commandImpl created ");
$			TaskEngineLocator locator = TaskEngineLocator.INSTANCE;
$			TaskEngine engine = locator.getTaskEngine();
$			try {
$				engine.submitTask(annotationCommandImpl);
$			} catch (RemoteException e) {
$				logger.error("Failed to communicate with the engine");
$			}
			
// end marker 1 }}

//TODO 1:
//Create an instance of your NamingPatternCommandImpl and and instance of 
// the NamingPatternReceiverImpl, set the NamingPatternReceiverImpl on the 
//NamingPatternCommandImpl and submit the NamingPatternCommandImpl to 
//the engine.

@			try {
@				Command namingPatternCommand = new NamingPatternCommandImpl();
@				namingPatternCommand.setReceiver(new NamingPatternReceiverImpl());
@				TaskEngineLocator locator = TaskEngineLocator.INSTANCE;
@				TaskEngine engine = locator.getTaskEngine();
@				engine.submitTask(namingPatternCommand);
@			} catch (RemoteException e) {
@				logger.error("Failed to communicate with the engine");
@			}
%TODO 1:<br/>&#160;&#160;try {<br/>&#160;&#160;&#160;&#160;Command namingPatternCommand = new NamingPatternCommandImpl();<br/>&#160;&#160;&#160;&#160;TaskEngineLocator locator = TaskEngineLocator.INSTANCE;<br/>&#160;&#160;&#160;&#160;TaskEngine engine = locator.getTaskEngine();<br/>&#160;&#160;&#160;&#160;namingPatternCommand.setReceiver(new NamingPatternReceiverImpl());<br/>&#160;&#160;&#160;&#160;engine.submitTask(namingPatternCommand);<br/>&#160;&#160;} catch (RemoteException e) {<br/>&#160;&#160;&#160;&#160;logger.error("Failed to communicate with the engine");<br/>&#160;&#160;}<br/><br/>





	}

}
