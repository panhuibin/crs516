package com.ltree.crs516.tasks;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.data.DataService;
import com.ltree.crs516.domain.Station;
import com.ltree.crs516.taskengine.DataServiceLocator;
import com.ltree.crs516.taskengine.Receiver;

 @SuppressWarnings("serial")
public final class NamingPatternReceiverImpl implements Serializable, Receiver {
	 
	private final Logger logger = LoggerFactory.getLogger(NamingPatternReceiverImpl.class);

	/* As long as method ends with 'action' or 'Action' it will be called 
	 * from execute() of CommandImpl.
	 * Order of invocation is not guaranteed.
	 */
	public void bytesInProfileAction() {
		logger.info("bytesInProfileAction called ");
		DataService dataService = DataServiceLocator.INSTANCE.getDataService();
		System.out.println("Number of bytes in profiles of stations");
		for (Station station : dataService) {
			System.out.println(station.getCountryCode());
		}
	}

//TODO 1: Create a public void method whose name ends with 'Action' and which 
//will print out the value of the latitude and longitude for each of 
//the stations.	
@	public void locationAction() {
@		logger.info("locationAction called ");
@		System.out.println("Location of stations");
@		DataService dataService = DataServiceLocator.INSTANCE.getDataService();
@		for (Station station : dataService) {
@			System.out.println("Latitude: "+ station.getLatitudeString()
@				+ "Longitude: "+ station.getLongitudeString());
@		}
@	}
$
$
$
$
$
$
$
$
% TODO 1: <br/>public void locationAction() {<br/>&#160;&#160;DataService dataService = DataServiceLocator.INSTANCE.getDataService();<br/>&#160;&#160;for (Station station : dataService) {<br/>&#160;&#160;&#160;&#160;System.out.println("Latitude: "+ station.getLatitudeString()<br/>&#160;&#160;&#160;&#160;&#160;&#160;+ "Longitude: "+ station.getLongitudeString());<br/>&#160;&#160;}<br/>}

//TODO 2: Create a public void method whose name ends with 'Action' and which will 
//print out the value of year property of each of the stations.	
@	public void yearAction() {
@		logger.info("yearAction called ");
@		System.out.println("Year property of stations");
@		DataService dataService = createDataService();
@		for (Station station : dataService) {
@			System.out.println(station.getYear());
@		}
@	}
$
$
$
$
$
$
$
$
% TODO 2: <br/>public void cruiseNumberAction() {<br/>&#160;&#160;DataService dataService = DataServiceLocator.INSTANCE.getDataService();<br/>&#160;&#160;for (Station station : dataService) {<br/>&#160;&#160;&#160;&#160;System.out.println(station.getYear());<br/>&#160;&#160;}<br/>}
	
}
