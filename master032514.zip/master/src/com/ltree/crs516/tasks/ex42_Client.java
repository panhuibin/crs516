package com.ltree.crs516.tasks;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.taskengine.TaskEngine;

public class Client {


	private final Logger logger = LoggerFactory.getLogger(Client.class);

	/**
	 * Looks up task engine, instantiates CommandImpl and submits it 
	 * to task engine.
	 */
	public void prepareAndSubmitCommand() {
		Registry registry;
		try {
			// Find the engine in the registry.
			registry = LocateRegistry.getRegistry(TaskEngine.hostName);
			TaskEngine engine = (TaskEngine) registry.lookup(TaskEngine.bindName);
			logger.info("engine located ");

//TODO 1: Create an instance of CompositeCommandImpl. 
			
@			CompositeCommandImpl cci = new CompositeCommandImpl();
$
%TODO 1:<br/>&#160;&#160;CompositeCommandImpl cci = new CompositeCommandImpl();<br/><br/>

//TODO 2: Create an instance of each of CommandImpl1, CommandImpl1,CommandImpl3, and add them to the 
//CompositeCommandImpl
			
@			CommandImpl1 c1 = new CommandImpl1();
@			CommandImpl2 c2 = new CommandImpl2();
@			CommandImpl3 c3 = new CommandImpl3();
@			cci.addCommand(c1);
@			cci.addCommand(c2);
@			cci.addCommand(c3);
$
$
$
$
$
$
$
%TODO 2:<br/>&#160;&#160;CommandImpl1 c1 = new CommandImpl1();<br/>&#160;&#160;CommandImpl2 c2 = new CommandImpl2();<br/>&#160;&#160;CommandImpl3 c3 = new CommandImpl3();<br/>&#160;&#160;cci.addCommand(c1);<br/>&#160;&#160;cci.addCommand(c2);<br/>&#160;&#160;cci.addCommand(c3);<br/><br/>

			logger.info("commandImpl created ");
			
//TODO 3: Submit the CompositeCommandImpl to the TaskEngine engine.
			
@			engine.submitTask(cci);
$
%TODO 3:<br/>&#160;&#160;engine.submitTask(cci);<br/><br/>

			logger.info("command submitted to task engine");			
		} catch (RemoteException e) {
			logger.error("Failed to get engine", e);
		} catch (NotBoundException e) {
			logger.error("Nothing bound under the name {}", TaskEngine.bindName, e);
		}
	}
}
