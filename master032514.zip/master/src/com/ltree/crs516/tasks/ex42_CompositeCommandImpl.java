package com.ltree.crs516.tasks;

import java.util.ArrayList;
import java.util.List;

import com.ltree.crs516.taskengine.Command;

 @SuppressWarnings("serial")
public class CompositeCommandImpl implements Command {

	private List<Command> commandList = new ArrayList<>();
	
	@Override
	public void run() {
		for (Command command : commandList) {
			command.run();
		}
	}

	public void addCommand(Command command){
		commandList.add(command);
	}
}
%<br/> public class CompositeCommandImpl implements Command {<br/> <br/> &#160;&#160;private List<Command> commandList = new ArrayList<>();<br/><br/>&#160;&#160;@Override<br/>&#160;&#160;public void run() {<br/>&#160;&#160;&#160;&#160;for (Command command : commandList) {<br/>&#160;&#160;&#160;&#160;&#160;&#160;command.run();<br/>&#160;&#160;&#160;&#160;}<br/>&#160;&#160;}<br/><br/>&#160;&#160;public void addCommand(Command command){<br/>&#160;&#160;&#160;&#160;commandList.add(command);<br/>&#160;&#160;}<br/><br/>} <br/><br/>
 
