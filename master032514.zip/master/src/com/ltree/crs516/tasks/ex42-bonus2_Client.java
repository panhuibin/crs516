package com.ltree.crs516.tasks;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ltree.crs516.taskengine.TaskEngine;

/**
 * Creates and submits CommandImpl to the task engine.
 * 
 * @author crs516 development team
 * 
 */
public final class Client {

	private final Logger logger = LoggerFactory.getLogger(Client.class);

	/**
	 * Looks up task engine, instantiates CommandImpl and submits it to task
	 * engine.
	 */
	public void prepareAndSubmitCommand() {
		try {
			
//TODO 1: Create an instance of CompositeCommandImpl and store the reference in the variable
//compositeCommandImpl below. 

@			CompositeCommandImpl compositeCommandImpl = new CompositeCommandImpl();
$
$
%TODO 1:<br/>&#160;&#160;CompositeCommandImpl compositeCommandImpl = new CompositeCommandImpl();<br/><br/>

//TODO 2: Create an instance of each of the three command classes CommandBytesInProfileImpl,
//CommandCountryImpl, and CommandCruiseNumberImpl adding them to compositeCommandImpl. 

@			compositeCommandImpl.addCommand(new CommandBytesInProfileImpl());
@			compositeCommandImpl.addCommand(new CommandCountryImpl());
@			compositeCommandImpl.addCommand(new CommandCruiseNumberImpl());
$
$
$
%TODO 2:<br/>&#160;&#160;compositeCommandImpl.add(new CommandBytesInProfileImpl());<br/>&#160;&#160;compositeCommandImpl.add(new CommandCountryImpl());<br/>&#160;&#160;compositeCommandImpl.add(new CommandCruiseNumberImpl());<br/><br/>
			logger.info("commandImpl created ");

//TODO 3: Get a reference to the task engine from the TaskEngineLocator.
			
@			TaskEngine engine = TaskEngineLocator.INSTANCE.getTaskEngine();
$
$
%TODO 3:<br/>&#160;&#160;TaskEngine engine = TaskEngineLocator.INSTANCE.getTaskEngine();<br/><br/>
			
//TODO 4: Submit compositeCommandImpl to the engine.
			
@			engine.submitTask(compositeCommandImpl);
$
$
%TODO 4:<br/>&#160;&#160;engine.submitTask(compositeCommandImpl);<br/><br/>
			logger.info("task submitted");
			
		} catch (RemoteException e) {
			logger.error(e.getMessage());
		}
	}

}
