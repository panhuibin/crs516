package com.ltree.crs516.taskengine;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TaskEngine extends Remote{

	static final String bindName = "TaskEngine";
	static final String hostName = "localhost";
	
	void submitTask(Command task) throws RemoteException;

	//TODO 1: 
	//Add a new method called stop to this interface that takes no argument 
	//throws RemoteException. The return type should be void.
@	void stop() throws RemoteException;
$
%TODO 1:<br/>&#160;&#160;void stop() throws RemoteException;<br/><br/>


}
