package com.ltree.crs516.client;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Observable;

import javax.swing.JEditorPane;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ltree.crs516.domain.Station;

public class CharacterDataTabTest {
	private CharacterDataTab testSubject;
	private JEditorPane textArea;
	private String testString = "No Character Data Present";
	private Station mockStation;
	private Observable mockObservable;
//TODO 1: Add a private field of type DisplayHelper called mockDisplayHelper;
	private DisplayHelper mockDisplayHelper;
	

	@Before
	public void setUp() throws Exception {
		testSubject = new CharacterDataTab();
//TODO 2: Get Mockito to initialize the mockDisplayHelper to a mock of the type DisplayHelper		
		mockDisplayHelper = Mockito.mock(DisplayHelper.class);
//TODO 3: call setHelper on testSubject and give it the mockDisplayHelper
		testSubject.setHelper(mockDisplayHelper);
		textArea = new JEditorPane("text/html", "");
		testSubject.setTextArea(textArea);
		mockStation = Mockito.mock(Station.class);
		mockObservable = Mockito.mock(Observable.class);
	}

	@Test
	public void testDisplay() {
//TODO 4: Configure the mockDisplayHelper so that when mineStation(mockStation) is called
// it returns testString.	
		when(mockDisplayHelper.mineStation(mockStation)).thenReturn(testString);
		testSubject.display(mockStation);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue(textArea.getText().contains(testString));
	}

	@Test
	public void testupdate() {
//TODO 5: Configure the mockDisplayHelper so that when mineStation(mockStation) is called
// it returns testString.	
		when(mockDisplayHelper.mineStation(mockStation)).thenReturn(testString);
		testSubject.update(mockObservable, mockStation);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue(textArea.getText().contains(testString));
	}

}
